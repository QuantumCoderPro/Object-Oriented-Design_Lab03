/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab03_721424060;

/**
 *
 * @author nmsaf
 */
public class OrderThread implements Runnable {
    private CoffeeShop coffeeShop;

    public OrderThread(CoffeeShop coffeeShop) {
        this.coffeeShop = coffeeShop;
    }

    @Override
    public void run() {
        synchronized (coffeeShop) {
            if (coffeeShop.getOrdersInProgress() > 0) {
                coffeeShop.completeOrder();
                System.out.println("Order completed for " + Thread.currentThread().getName() +
                        " at " + coffeeShop.getShopName() + ". Orders in progress: " +
                        coffeeShop.getOrdersInProgress());
            }
        }
    }
}