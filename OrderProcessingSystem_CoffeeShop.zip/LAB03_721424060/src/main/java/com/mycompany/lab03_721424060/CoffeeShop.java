/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab03_721424060;

/**
 *
 * @author nmsaf
 */
public class CoffeeShop {
    private String shopName;
    private int ordersInProgress;

    public CoffeeShop(String shopName, int ordersInProgress) {
        this.shopName = shopName;
        this.ordersInProgress = ordersInProgress;
    }

    public synchronized void completeOrder() {
        if (ordersInProgress > 0) {
            ordersInProgress--;
        }
    }

    public int getOrdersInProgress() {
        return ordersInProgress;
    }

    public String getShopName() {
        return shopName;
    }
}