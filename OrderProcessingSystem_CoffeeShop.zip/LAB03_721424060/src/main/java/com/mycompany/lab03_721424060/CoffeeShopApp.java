/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.lab03_721424060;

/**
 *
 * @author nmsaf
 */
public class CoffeeShopApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int initialOrdersInProgress = 20;
        CoffeeShop coffeeShop = new CoffeeShop("Steamy Beans Coffee", initialOrdersInProgress);

        int numThreads = 5;
        Thread[] threads = new Thread[numThreads];

        for (int i = 0; i < numThreads; i++) {
            threads[i] = new Thread(new OrderThread(coffeeShop));
            threads[i].start();
        }

        for (int i = 0; i < numThreads; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Final number of orders in progress at " + coffeeShop.getShopName() +
                ": " + coffeeShop.getOrdersInProgress());
    }
}